#### 项目需要的依赖包在requirement.txt

#### 安装依赖后，使用vscode打开myapp文件夹

#### 运行app.py

#### 打开http://127.0.0.1:8050/即可

#### 第一个数据有25M，datainfo.py是对数据进行了预处理，在dash解析数据的时候更快

